import os
import django

from django.db.models import Q, Count


# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here

from main_app.models import Astronaut, Mission

# Create queries within functions
def get_astronauts(search_string=None) -> str:
    if search_string is None:
        return ''
    
    astronauts = Astronaut.objects.filter(
            Q(name__icontains=search_string) | Q(phone_number__icontains=search_string)
        )
    
    astronauts = astronauts.order_by('name')
    
    if not astronauts.exists():
        return ''
        
    result = []
    
    for astronaut in astronauts:
        status = 'Active' if astronaut.is_active else 'Inactive'
        result.append(f"Astronaut: {astronaut.name}, phone number: {astronaut.phone_number}, status: {status}")
    
    return '\n'.join(result)


def get_top_astronaut() -> str:
    top_astronaut = Astronaut.objects.get_astronauts_by_missions_count().first()
    
    if not top_astronaut or top_astronaut.missions_count == 0:
        return 'No data.'
    
    return f'Top Astronaut: {top_astronaut.name} with {top_astronaut.missions_count} missions.'
    

def get_top_commander() -> str:
    top_commander = Astronaut.objects.annotate(
        missions_count=Count('commanded_missions')
    ).filter(
        missions_count__gt=0
    ).order_by(
        '-missions_count',
        'phone_number'
    ).first()

    if not top_commander:
        return "No data."
        
    return f'Top Commander: {top_commander.name} with {top_commander.missions_count} commanded missions.'
    